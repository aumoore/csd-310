-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bacchus
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
  `supplier_id` varchar(30) NOT NULL,
  `expected_delivery` varchar(30) NOT NULL,
  `jan_delivery` varchar(10) DEFAULT NULL,
  `feb_delivery` varchar(10) DEFAULT NULL,
  `mar_delivery` varchar(10) DEFAULT NULL,
  `apr_delivery` varchar(10) DEFAULT NULL,
  `may_delivery` varchar(10) DEFAULT NULL,
  `jun_delivery` varchar(10) DEFAULT NULL,
  `jul_delivery` varchar(10) DEFAULT NULL,
  `aug_delivery` varchar(10) DEFAULT NULL,
  `sept_delivery` varchar(10) DEFAULT NULL,
  `oct_delivery` varchar(10) DEFAULT NULL,
  `nov_delivery` varchar(10) DEFAULT NULL,
  `dec_delivery` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES ('Supplier1','100','100','100','80','90','100','100','100','90','100','100','100','70'),('Supplier2','100','90','100','100','100','90','80','70','70','100','100','100','100'),('Supplier3','100','100','100','100','100','90','100','100','100','100','90','100','90');
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distribution`
--

DROP TABLE IF EXISTS `distribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `distribution` (
  `product_id` int DEFAULT NULL,
  `product_name` varchar(75) DEFAULT NULL,
  `distributor_id` int DEFAULT NULL,
  `product_sales` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distribution`
--

LOCK TABLES `distribution` WRITE;
/*!40000 ALTER TABLE `distribution` DISABLE KEYS */;
INSERT INTO `distribution` VALUES (1,'Merlot',1001,50000),(2,'Cabernet',1002,40000),(3,'Chablis',1003,30000),(4,'Chardonnay',1004,20000);
/*!40000 ALTER TABLE `distribution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee1`
--

DROP TABLE IF EXISTS `employee1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee1` (
  `employee_first_name` varchar(75) DEFAULT NULL,
  `employee_last_name` varchar(75) DEFAULT NULL,
  `employee_role` varchar(75) DEFAULT NULL,
  `employee_id` int DEFAULT NULL,
  `employee_weekly_hours` int DEFAULT NULL,
  `quarterly_hours` varchar(20) DEFAULT NULL,
  `quarters` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee1`
--

LOCK TABLES `employee1` WRITE;
/*!40000 ALTER TABLE `employee1` DISABLE KEYS */;
INSERT INTO `employee1` VALUES ('Stan','Bacchus','Owner',1,40,'500','4'),('Davis','Bacchus','Owner',2,40,'465','4'),('Janet','Collins','Finance_Manager',3,40,'480','4'),('Bob','Ulrich','Marketing_Manager_Assistant',5,40,'425','4'),('Henry','Doyle','Production_Manager',6,40,'400','4'),('Maria','Costanza','Distribution_Manager',7,40,'415','4'),('Roz','Murphy','Marketing_Manager',4,40,'475','4');
/*!40000 ALTER TABLE `employee1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `supplier_id` varchar(75) DEFAULT NULL,
  `shipping_frequency` varchar(75) DEFAULT NULL,
  `supply_name` varchar(75) DEFAULT NULL,
  `supply_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES ('Supplier1','Monthly','Bottles',101),('Supplier1','Monthly','Corks',102),('Supplier2','Monthly','Labels',103),('Supplier2','Monthly','Boxes',104),('Supplier3','Monthly','Vats',105),('Supplier3','Monthly','Tubing',106);
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'bacchus'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-03  0:03:24
